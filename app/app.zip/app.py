import math
import sys
import random
from PyQt6 import uic
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QApplication, QFrame, QVBoxLayout, QSplitter, QMessageBox, \
    QDialog

# Управление визуальными эффектами: таймеры, пошаговая перекраска узлов и ребер
from qt.Main_App.engine.animations import AnimateNodeAndEdges
# Графические примитивы: классы Node (узлы) и Edge (ребра) на базе QGraphicsItem
from qt.Main_App.engine.items_graph import Edge, Node

# логика: GraphControl (хранение данных) и Algoritm (математика/поиск)
from qt.Main_App.engine.logic import GraphControl, Algoritm

# Графический холст: MyScene (слой объектов) и MyView (камера, зум, клики)
from qt.Main_App.engine.scene_paint import MyScene, MyView

# Кастомные UI-элементы: стилизованные кнопки и боковые меню управления
from qt.Main_App.engine.widgets import isAddButton, isClickButton, GraphInput, isAddEdgeButton

from engine.GraphVisual import *



class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setMinimumSize(1280, 720)
        self.central_widget = QSplitter(Qt.Orientation.Horizontal) #для смены ширины пользователем, доработать позже
        self.edges_dict = {}
        self.setCentralWidget(self.central_widget)
        self.main_layout = QHBoxLayout(self.central_widget)
        self.visual_nodes = {}
        self.list_edge = dict()



        self.sidebar()
        self.scene_w()

        self.addClickBtn.clicked.connect(self.view.enable_click_btn) #хуйня, переделать после в сайдбар либо в сам класс
        self.addEdgesBtn.clicked.connect(self.view.click_btn_add_edges)

        self.graphvisualiser = GraphVisual(self.scene, self.graph_control, self)


        # test_matrix = [
        #     [0, 1, 0, 1, 0, 0, 1, 0, 1, 1],
        #     [1, 0, 1, 0, 0, 1, 0, 1, 0, 0],
        #     [0, 1, 0, 0, 0, 0, 1, 1, 0, 1],
        #     [1, 0, 0, 0, 1, 1, 0, 0, 1, 0],
        #     [0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
        #     [0, 1, 0, 1, 0, 0, 1, 0, 1, 0],
        #     [1, 0, 1, 0, 0, 1, 0, 1, 0, 0],
        #     [0, 1, 1, 0, 1, 0, 1, 0, 0, 1],
        #     [1, 0, 0, 0, 0, 1, 0, 0, 0, 1],
        #     [1, 0, 1, 0, 1, 0, 0, 1, 1, 0]
        # ]
        # test_matrix = self.generate_matrix(7)
        # self.ellipse_xy_draw(test_matrix)

        self.algoritm = Algoritm()
        # self.list_test = self.algoritm.matrix_to_list(test_matrix)

        self.rightMenu()

    def sidebar(self):
        self.bar = QFrame()

        self.bar.setStyleSheet("background-color: #2c3e50;")

        self.addNodesBtn = isAddButton()
        self.addClickBtn = isClickButton()
        self.addEdgesBtn = isAddEdgeButton()

        self.layout_bar = QVBoxLayout(self.bar)
        self.layout_bar.addWidget(self.addNodesBtn)
        self.layout_bar.addWidget(self.addClickBtn)
        self.layout_bar.addWidget(self.addEdgesBtn)
        self.layout_bar.addStretch(1)


        self.addNodesBtn.menu_add.actions()[0].triggered.connect(self.add_list_dialog)
        self.addNodesBtn.menu_add.actions()[1].triggered.connect(self.add_matrix_dialog)

        self.main_layout.addWidget(self.bar)

    def add_list_dialog(self):
        dialog = GraphInput(self)
        dialog.text_edit.setPlaceholderText("""Введите граф списком, пример:
                1: 2, 3
                2: 1, 3
                3: 1, 2
                """)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            text = dialog.get_text()
            print(text)
            #после доделать
    def add_matrix_dialog(self):
        dialog = GraphInput(self)
        dialog.text_edit.setPlaceholderText("""Введите граф матрице, пример:
        0 1 1
        1 0 1
        1 1 0
        """)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            text = dialog.get_text()
            print(text)
            try:
                matrix = []
                for line in text.strip().split('\n'):
                    if line.strip():
                        matrix.append([int(x) for x in line.split()])

                size = len(matrix)
                for x in matrix:
                    if(len(x)) != size:
                        raise ValueError("Матрица должна быть квадратичная")
                self.graphvisualiser.ellipse_xy_draw(matrix)
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", f"Неверный формат - {e}")



    def scene_w(self):
        self.graph_control = GraphControl()
        self.scene = MyScene()
        self.view = MyView(self.scene, self.graph_control, self)
        self.main_layout.addWidget(self.view)

    def rightMenu(self):
        self.RightBar = QWidget()
        uic.loadUi('ui/leftmenunode.ui', self.RightBar)
        self.main_layout.addWidget(self.RightBar)
        self.RightBar.setFixedWidth(300)
        self.RightBar.btnStartAlgo.clicked.connect(self.click_start_algo)
    def click_start_algo(self):
        print('Нажато')
        text_algo = self.RightBar.algorithm_list.currentText()
        print(text_algo)
        if "DFS (Обход в глубину)" == text_algo:

            # self.res_bfs = self.algoritm.dfs_2path(self.list_test, 1)
            try:
                start = int(self.RightBar.lineEdit_Node.text())
            except ValueError:
                start = 1
            list = self.graph_control.get_graph()
            self.res_bfs = self.algoritm.dfs_2path(list, start)
            self.k = AnimateNodeAndEdges()
            self.k.bfs_animate(self.visual_nodes, self.list_edge, self.res_bfs, 500)
        elif "BFS (Поиск в ширину)" == text_algo:
            pass
    def update_ui_node(self, node_id):
        self.RightBar.lineEdit_Node.setText(str(node_id))


    def graph_clear(self):
        self.graph_control.clear()
        self.scene.clear()
        self.visual_nodes = {}
        self.list_edge = {}
        self.RightBar.lineEdit_Node.clear()
    # def ellipse_xy_draw(self, test_matrix, radius = 1111):
    #     self.graph_clear()
    #     self.visual_nodes = {}
    #     self.list_edge = dict()
    #     self.graph_control.clear()
    #
    #     for i in range(len(test_matrix)):
    #         angle = 2 * math.pi * i / len(test_matrix)
    #         x = radius * math.cos(angle)
    #         y = radius * math.sin(angle)
    #         new_id = self.graph_control.add_node()
    #         new_N = Node(new_id, x, y)
    #         # self.list_node.append(new_N)
    #         self.visual_nodes[new_id] = new_N
    #         self.scene.addItem(new_N)
    #
    #     for i in range(len(test_matrix)):
    #         for j in range(len(test_matrix)):
    #             if (test_matrix[i][j]) > 0:
    #                 source = i + 1
    #                 dst = j + 1
    #                 self.graph_control.add_edge(source, dst)
    #                 # new_Edge = Edge(self.list_node[i], self.list_node[j], test_matrix[i][j])
    #                 if f'{dst}-{source}' not in self.list_edge:
    #                     # new_Edge = Edge(self.visual_nodes[source], self.visual_nodes[dst], test_matrix[i][j])
    #                     # self.scene.addItem(new_Edge)
    #                     # self.list_edge[f'{source}-{dst}'] = new_Edge
    #                     #
    #                     # self.list_node[i].add_edge(new_Edge)
    #                     # self.list_node[j].add_edge(new_Edge) хуйня, снизу с ИИ получше
    #
    #                     # 1. Берем объекты Node из словаря visual_nodes по их ID
    #                     node_source = self.visual_nodes[source]
    #                     node_dst = self.visual_nodes[dst]
    #
    #                     # 2. Создаем графическое ребро
    #                     new_Edge = Edge(node_source, node_dst, test_matrix[i][j])
    #                     self.scene.addItem(new_Edge)
    #
    #                     # 3. Сохраняем ребро в словарь ОБЕИМИ сторонами (ключевой момент для аниматора!)
    #                     self.list_edge[f'{source}-{dst}'] = new_Edge
    #                     self.list_edge[f'{dst}-{source}'] = new_Edge
    #
    #                     # 4. Регистрируем ребро в самих узлах (чтобы линии тянулись при перетаскивании)
    #                     node_source.add_edge(new_Edge)
    #                     node_dst.add_edge(new_Edge)


    def generate_matrix(self, size):
        return [[1 if random.random() > 0.8 else 0 for _ in range(size)] for _ in range(size)]




class StartMenu(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi('ui/menubeta1.ui', self)

        self.cardNewProject = self.findChild(QFrame, 'frame_2')
        self.setStyleSheet("QWidget { background-color: white; color: black; }")

        if self.cardNewProject:
            self.cardNewProject.installEventFilter(self)
            self.cardNewProject.setCursor(Qt.CursorShape.PointingHandCursor)
        else:
            print("Иди нах, нет такого файла")

    def eventFilter(self, obj, event):
        if obj == self.cardNewProject and event.type() == event.Type.MouseButtonPress:
            if event.button() == Qt.MouseButton.LeftButton:
                self.open_main_program()
                return True
        return super().eventFilter(obj, event)

    def open_main_program(self):
        self.main_window = Window()
        self.main_window.show()
        self.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    # window = Window()
    # # apply_stylesheet(app, theme='dark_teal.xml')
    # window.show()
    menu = StartMenu()
    menu.show()
    sys.exit(app.exec())