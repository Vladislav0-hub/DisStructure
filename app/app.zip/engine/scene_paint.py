from PyQt6.QtCore import Qt
from PyQt6.QtGui import QBrush
from PyQt6.QtWidgets import QGraphicsScene, \
    QGraphicsView
from qt.Main_App.engine.items_graph import Edge, Node
from qt.Main_App.engine.logic import GraphControl
class MyScene(QGraphicsScene):
    def __init__(self):
        super().__init__()
        self.cntNode = 2
        #self.setSceneRect(-500, -500, 1000, 1000)
        self.setSceneRect(-5000, -5000, 10000, 10000)


class MyView(QGraphicsView):
    def __init__(self, scene, graph_control:GraphControl, main_window):
        super().__init__(scene)
        self.my_scene = scene
        self.window = main_window
        self.setBackgroundBrush(QBrush(Qt.GlobalColor.white))
        self.graph_control = graph_control
        self.click = False
        self.add_edges_click = False
        self.first_node = None


        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)


    def mousePressEvent(self, event):
        pos = event.pos()
        item = self.itemAt(pos)
        if item and not isinstance(item, Node):
            parent = item.parentItem()
            if isinstance(parent, Node):
                item = parent #ии
        if self.click:
            if not item:
                self.setDragMode(QGraphicsView.DragMode.NoDrag)
                pos = self.mapToScene(pos) #перевод в координаты сцены, т.к. я сделал цену отсчета от нуля
                new_id = self.graph_control.add_node()
                n_add = Node(new_id, pos.x(), pos.y())
                self.my_scene.addItem(n_add)
                self.window.visual_nodes[new_id] = n_add
        elif self.add_edges_click:
            if not item and self.first_node:
                self.first_node.resetColor()
                self.first_node = None
            if isinstance(item, Node):
                if not self.first_node:
                    self.first_node = item
                    self.first_node.changeColor('#FFFF00')
                elif self.first_node and item:
                    self.first_node.resetColor()
                    self.window.graphvisualiser.add_visual_edge(self.first_node, item)
                    self.first_node = None




        else:
            self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        if isinstance(item, Node):
            node_id = int(item.text_item.toPlainText())
            self.window.update_ui_node(node_id)


        super().mousePressEvent(event)

    def enable_click_btn(self):
        self.click = not self.click
        if self.click:
            self.add_edges_click = False
    def click_btn_add_edges(self):
        if self.first_node:
            self.first_node.resetColor()
            self.first_node = None
        self.add_edges_click = not self.add_edges_click
        if self.add_edges_click:
            self.click = False


    #зум
    def wheelEvent(self, event):
        factor = 1.1 if event.angleDelta().y() > 0 else 0.9
        self.scale(factor, factor)


