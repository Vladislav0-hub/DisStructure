class Algoritm():
    @staticmethod
    def matrix_to_list( graph):
        length = len(graph)
        res = list()
        for i in range(1, length+1):
            s = []
            for x in range(0, length):
                if(graph[i-1][x] > 0):
                    s.append(x+1)
            res.append(s)
        return res

    @staticmethod
    def dfs(graph, start):
        visited = set()
        stack = [start]
        node_visit = []
        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                node_visit.append(vertex)
                visited.add(vertex)
                for neighbor in reversed(graph[vertex-1]):
                    if neighbor not in visited:
                        stack.append(neighbor)
        return node_visit

    @staticmethod
    def dfs_2path(graph, start):
        visited = set()
        stack = [[0, start]]
        node_visit = []
        while stack:
            source, vertex = stack.pop()
            if vertex not in visited:
                visited.add(vertex)
                node_visit.append([source, vertex])
                # Достаем соседей по ключу (id узла)
                if vertex in graph:
                    for neighbor in reversed(graph[vertex]):
                        if neighbor not in visited:
                            stack.append([vertex, neighbor])
        return node_visit

class GraphControl():
    """списками смежностей"""
    def __init__(self):
        self.list = {}
        self.cnt_node = 0
    def add_node(self):
        self.cnt_node += 1
        id = self.cnt_node
        self.list[id] = []
        return id
    def add_edge(self, source, dst):
        """в виде id"""
        if source in self.list and dst in self.list:
            if dst not in self.list[source]:
                self.list[source].append(dst)
            if source not in self.list[dst]:
                self.list[dst].append(source)
    def clear(self):
        self.list = {}
        self.cnt_node = 0
    def get_graph(self):
        return self.list
