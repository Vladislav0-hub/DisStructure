import math
import sys
import random
from PyQt6 import uic
from PyQt6.QtCore import Qt, QRectF, QLine, QLineF, QSize, QTimer
from PyQt6.QtGui import QBrush, QColor, QPen, QIcon, QStandardItemModel, QStandardItem, QAction
from PyQt6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QApplication, QFrame, QVBoxLayout, QGraphicsScene, \
    QGraphicsView, QGraphicsEllipseItem, QGraphicsItem, QGraphicsLineItem, QGraphicsTextItem, QPushButton, \
    QGraphicsDropShadowEffect, QTableView, QHeaderView, QSplitter, QLabel, QMessageBox, QMenu

class AnimateNodeAndEdges():
    def bfs_animate(self, list_nodes,list_edge, res_bfs, time_sec):
        self.list_nodes = list_nodes
        self.list_edge = list_edge
        self.res_bfs = res_bfs
        self.timer = QTimer()
        self.clearColor(list_nodes,list_edge)
        self.timer.timeout.connect(self.animatebfsnode)
        self.timer.start(time_sec)
        self.old = -1
    def animatebfsnode(self):
        if self.res_bfs:
            source,dst = self.res_bfs.pop(0)
            node = self.list_nodes.get(dst)
            if node:
                node.changeColor()
            if source > 0:
                print(f" {source} - {dst}")
                edge = self.list_edge.get(f"{source}-{dst}")
                if edge:
                    edge.changeColor()
        else:
            self.timer.stop()

    def clearColor(self,list_nodes,list_edge):
        nodes = list_nodes.values() if isinstance(list_nodes, dict) else list_nodes
        for x in nodes:
            x.resetColor()
        for x in list_edge.values():
            x.resetColor()
