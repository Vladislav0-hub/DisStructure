import math
import sys
import random
from PyQt6 import uic
from PyQt6.QtCore import Qt, QRectF, QLine, QLineF, QSize, QTimer
from PyQt6.QtGui import QBrush, QColor, QPen, QIcon, QStandardItemModel, QStandardItem, QAction
from PyQt6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QApplication, QFrame, QVBoxLayout, QGraphicsScene, \
    QGraphicsView, QGraphicsEllipseItem, QGraphicsItem, QGraphicsLineItem, QGraphicsTextItem, QPushButton, \
    QGraphicsDropShadowEffect, QTableView, QHeaderView, QSplitter, QLabel, QMessageBox, QMenu


class Edge(QGraphicsLineItem):
    def __init__(self, source, dst,weight=0):
        super().__init__()
        self.source = source
        self.dst = dst
        self.setPen(QPen(QColor("#94A3B8"), 2))
        self.text_item = QGraphicsTextItem(str(weight), self)
        self.update_pos()
        self.setZValue(-2)


    def update_pos(self):
        pos_source = self.source.pos()
        pos_dst = self.dst.pos()
        self.setLine(pos_source.x(), pos_source.y(), pos_dst.x(), pos_dst.y())
        self.center_text()

    def center_text(self):
       k = self.line().center()
       self.text_item.setPos(k.x(), k.y())

    def changeColor(self):
        self.setPen(QPen(QColor("#10b981"), 2))
        self.setZValue(-1)

    def resetColor(self):
        self.setPen(QPen(QColor("#94A3B8"), 2))




class Node(QGraphicsEllipseItem):
    def __init__(self,node_id ,x,y):
        super().__init__(-15,-15,30,30)
        self.setCacheMode(QGraphicsItem.CacheMode.DeviceCoordinateCache)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setOffset(5, 5)  # смещение тени (x, y)
        shadow.setColor(QColor(0, 0, 0, 60))
        self.setData(0, node_id)
        self.setGraphicsEffect(shadow)
        self.edges = []
        self.setPos(x, y)
        self.setPen(QPen(QColor("#94A3B8"), 2))

        self.setBrush(QBrush(QColor(Qt.GlobalColor.white)))

        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges)

        self.text_item = QGraphicsTextItem(str(node_id), self)
        self.text_item.setDefaultTextColor(Qt.GlobalColor.black)
        self.center_text()


    def get_edge(self, dst_node):
        for edge in self.edges:
            if edge.dst == dst_node:
                return edge
        return None
    def center_text(self):
        center = self.text_item.boundingRect()
        self.text_item.setPos(-center.width()/2,-center.height()/2)

    def add_edge(self, edgesss):
        self.edges.append(edgesss)

    def itemChange(self, change, value):
        if change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
            for edge in self.edges:
                edge.update_pos()
        return super().itemChange(change, value)
    def changeColor(self, color="#10b981"):
        self.setBrush(QBrush(QColor(color)))
        self.setPen(QPen(QColor(color), 2))

    def resetColor(self):
        self.setPen(QPen(QColor("#94A3B8"), 2))
        self.setBrush(QBrush(QColor(Qt.GlobalColor.white)))

    # def mousePressEvent(self, event):
    #     self.RightBar.lineEdit_Node.clear()