import math

from .items_graph import Edge, Node

#доделать


class GraphVisual():
    def __init__(self, scene, graph_control, window):
        self.scene = scene
        self.graph_control = graph_control
        self.window = window

    def add_visual_edge(self, node_u, node_v, weight=1):
        """Принимает объекты Node, а не их ID"""
        # 1. Вытягиваем ID для логики (контроллера)
        # Предполагаем, что ID хранится в node.id или вынимается из текста
        u_id = int(node_u.text_item.toPlainText())
        v_id = int(node_v.text_item.toPlainText())

        # 2. Обновляем логику (мозг программы)
        self.graph_control.add_edge(u_id, v_id)

        # 3. Создаем графику
        new_edge = Edge(node_u, node_v, weight)
        self.scene.addItem(new_edge)

        # 4. Регистрируем в общих словарях окна
        self.window.list_edge[f"{u_id}-{v_id}"] = new_edge
        self.window.list_edge[f"{v_id}-{u_id}"] = new_edge

        # 5. Привязываем ребро к узлам (для движения)
        node_u.add_edge(new_edge)
        node_v.add_edge(new_edge)

        return new_edge

    def ellipse_xy_draw(self, matrix, radius=1111):
        self.window.graph_clear()
        size = len(matrix)

        # Создаем узлы и сразу сохраняем ссылки на них в список
        nodes_refs = []
        for i in range(size):
            angle = 2 * math.pi * i / size
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)

            new_id = self.graph_control.add_node()
            new_node = Node(new_id, x, y)

            self.window.visual_nodes[new_id] = new_node
            self.scene.addItem(new_node)
            nodes_refs.append(new_node)

        # Рисуем ребра, передавая ссылки на объекты
        for i in range(size):
            for j in range(size):
                if matrix[i][j] > 0:
                    # i и j - это индексы в списке nodes_refs
                    u_node = nodes_refs[i]
                    v_node = nodes_refs[j]

                    u_id = i + 1
                    v_id = j + 1

                    if f"{v_id}-{u_id}" not in self.window.list_edge:
                        self.add_visual_edge(u_node, v_node, matrix[i][j])