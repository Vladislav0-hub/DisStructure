import math
import sys
import random
from PyQt6 import uic
from PyQt6.QtCore import Qt, QRectF, QLine, QLineF, QSize, QTimer
from PyQt6.QtGui import QBrush, QColor, QPen, QIcon, QStandardItemModel, QStandardItem, QAction
from PyQt6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QApplication, QFrame, QVBoxLayout, QGraphicsScene, \
    QGraphicsView, QGraphicsEllipseItem, QGraphicsItem, QGraphicsLineItem, QGraphicsTextItem, QPushButton, \
    QGraphicsDropShadowEffect, QTableView, QHeaderView, QSplitter, QLabel, QMessageBox, QMenu


class Algoritm():
    @staticmethod
    def matrix_to_list( graph):
        length = len(graph)
        res = list()
        for i in range(1, length+1):
            s = []
            for x in range(0, length):
                if(graph[i-1][x] > 0):
                    s.append(x+1)
            res.append(s)
        return res

    @staticmethod
    def dfs(graph, start):
        visited = set()
        stack = [start]
        node_visit = []
        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                node_visit.append(vertex)
                visited.add(vertex)
                for neighbor in reversed(graph[vertex-1]):
                    if neighbor not in visited:
                        stack.append(neighbor)
        return node_visit

    @staticmethod
    def dfs_2path(graph, start):
        visited = set()
        stack = [[0, start]]
        node_visit = []
        while stack:
            source, vertex = stack.pop()
            if vertex not in visited:
                visited.add(vertex)
                node_visit.append([source, vertex])
                # Достаем соседей по ключу (id узла)
                if vertex in graph:
                    for neighbor in reversed(graph[vertex]):
                        if neighbor not in visited:
                            stack.append([vertex, neighbor])
        return node_visit

class AnimateNodeAndEdges():
    def bfs_animate(self, list_nodes,list_edge, res_bfs, time_sec):
        self.list_nodes = list_nodes
        self.list_edge = list_edge
        self.res_bfs = res_bfs
        self.timer = QTimer()
        self.clearColor(list_nodes,list_edge)
        self.timer.timeout.connect(self.animatebfsnode)
        self.timer.start(time_sec)
        self.old = -1
    def animatebfsnode(self):
        if self.res_bfs:
            source,dst = self.res_bfs.pop(0)
            node = self.list_nodes.get(dst)
            if node:
                node.changeColor()
            if source > 0:
                print(f" {source} - {dst}")
                edge = self.list_edge.get(f"{source}-{dst}")
                if edge:
                    edge.changeColor()
        else:
            self.timer.stop()

    def clearColor(self,list_nodes,list_edge):
        nodes = list_nodes.values() if isinstance(list_nodes, dict) else list_nodes
        for x in nodes:
            x.resetColor()
        for x in list_edge.values():
            x.resetColor()



class GraphControl():
    """списками смежностей"""
    def __init__(self):
        self.list = {}
        self.cnt_node = 0
    def add_node(self):
        self.cnt_node += 1
        id = self.cnt_node
        self.list[id] = []
        return id
    def add_edge(self, source, dst):
        """в виде id"""
        if source in self.list and dst in self.list:
            if dst not in self.list[source]:
                self.list[source].append(dst)
            if source not in self.list[dst]:
                self.list[dst].append(source)
    def clear(self):
        self.list = {}
        self.cnt_node = 0
    def get_graph(self):
        return self.list


class Edge(QGraphicsLineItem):
    def __init__(self, source, dst,weight=0):
        super().__init__()
        self.source = source
        self.dst = dst
        self.setPen(QPen(QColor("#94A3B8"), 2))
        self.text_item = QGraphicsTextItem(str(weight), self)
        self.update_pos()
        self.setZValue(-2)


    def update_pos(self):
        pos_source = self.source.pos()
        pos_dst = self.dst.pos()
        self.setLine(pos_source.x(), pos_source.y(), pos_dst.x(), pos_dst.y())
        self.center_text()

    def center_text(self):
       k = self.line().center()
       self.text_item.setPos(k.x(), k.y())

    def changeColor(self):
        self.setPen(QPen(QColor("#10b981"), 2))
        self.setZValue(-1)

    def resetColor(self):
        self.setPen(QPen(QColor("#94A3B8"), 2))




class Node(QGraphicsEllipseItem):
    def __init__(self,node_id ,x,y):
        super().__init__(-15,-15,30,30)
        self.setCacheMode(QGraphicsItem.CacheMode.DeviceCoordinateCache)
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setOffset(5, 5)  # смещение тени (x, y)
        shadow.setColor(QColor(0, 0, 0, 60))
        self.setData(0, node_id)
        self.setGraphicsEffect(shadow)
        self.edges = []
        self.setPos(x, y)
        self.setPen(QPen(QColor("#94A3B8"), 2))

        self.setBrush(QBrush(QColor(Qt.GlobalColor.white)))

        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsMovable)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges)

        self.text_item = QGraphicsTextItem(str(node_id), self)
        self.text_item.setDefaultTextColor(Qt.GlobalColor.black)
        self.center_text()


    def get_edge(self, dst_node):
        for edge in self.edges:
            if edge.dst == dst_node:
                return edge
        return None
    def center_text(self):
        center = self.text_item.boundingRect()
        self.text_item.setPos(-center.width()/2,-center.height()/2)

    def add_edge(self, edgesss):
        self.edges.append(edgesss)

    def itemChange(self, change, value):
        if change == QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:
            for edge in self.edges:
                edge.update_pos()
        return super().itemChange(change, value)
    def changeColor(self):
        self.setBrush(QBrush(QColor("#10b981")))
        self.setPen(QPen(QColor("#10b981"), 2))

    def resetColor(self):
        self.setPen(QPen(QColor("#94A3B8"), 2))
        self.setBrush(QBrush(QColor(Qt.GlobalColor.white)))

    # def mousePressEvent(self, event):
    #     self.RightBar.lineEdit_Node.clear()

class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setMinimumSize(1280, 720)
        self.central_widget = QSplitter(Qt.Orientation.Horizontal) #для смены ширины пользователем, доработать позже
        self.edges_dict = {}
        self.setCentralWidget(self.central_widget)
        self.main_layout = QHBoxLayout(self.central_widget)


        self.sidebar()
        self.scene_w()

        self.addClickBtn.clicked.connect(self.view.enable_click_btn) #хуйня, переделать после в сайдбар либо в сам класс



        # test_matrix = [
        #     [0, 1, 0, 1, 0, 0, 1, 0, 1, 1],
        #     [1, 0, 1, 0, 0, 1, 0, 1, 0, 0],
        #     [0, 1, 0, 0, 0, 0, 1, 1, 0, 1],
        #     [1, 0, 0, 0, 1, 1, 0, 0, 1, 0],
        #     [0, 0, 0, 0, 0, 0, 0, 1, 0, 1],
        #     [0, 1, 0, 1, 0, 0, 1, 0, 1, 0],
        #     [1, 0, 1, 0, 0, 1, 0, 1, 0, 0],
        #     [0, 1, 1, 0, 1, 0, 1, 0, 0, 1],
        #     [1, 0, 0, 0, 0, 1, 0, 0, 0, 1],
        #     [1, 0, 1, 0, 1, 0, 0, 1, 1, 0]
        # ]
        test_matrix = self.generate_matrix(5)
        self.ellipse_xy_draw(test_matrix)

        self.algoritm = Algoritm()
        self.list_test = self.algoritm.matrix_to_list(test_matrix)

        self.rightMenu()

    def sidebar(self):
        self.bar = QFrame()

        self.bar.setStyleSheet("background-color: #2c3e50;")

        self.addNodesBtn = isAddButton()
        self.addClickBtn = isClickButton()


        self.layout_bar = QVBoxLayout(self.bar)
        self.layout_bar.addWidget(self.addNodesBtn)
        self.layout_bar.addWidget(self.addClickBtn)
        self.layout_bar.addStretch(1)


        self.main_layout.addWidget(self.bar)
    def scene_w(self):
        self.graph_control = GraphControl()
        self.scene = MyScene()
        self.view = MyView(self.scene, self.graph_control, self)
        self.main_layout.addWidget(self.view)

    def rightMenu(self):
        self.RightBar = QWidget()
        uic.loadUi('leftmenunode.ui', self.RightBar)
        self.main_layout.addWidget(self.RightBar)
        self.RightBar.setFixedWidth(300)
        self.RightBar.btnStartAlgo.clicked.connect(self.click_start_algo)
    def click_start_algo(self):
        print('Нажато')
        text_algo = self.RightBar.algorithm_list.currentText()
        print(text_algo)
        if "DFS (Обход в глубину)" == text_algo:
            # self.res_bfs = self.algoritm.dfs_2path(self.list_test, 1)
            try:
                start = int(self.RightBar.lineEdit_Node.text())
            except ValueError:
                start = 1
            list = self.graph_control.get_graph()
            self.res_bfs = self.algoritm.dfs_2path(list, start)
            self.k = AnimateNodeAndEdges()
            self.k.bfs_animate(self.visual_nodes, self.list_edge, self.res_bfs, 500)
        elif "BFS (Поиск в ширину)" == text_algo:
            pass
    def update_ui_node(self, node_id):
        self.RightBar.lineEdit_Node.setText(str(node_id))



    def ellipse_xy_draw(self, test_matrix, radius = 111):
        self.visual_nodes = {}
        self.list_edge = dict()
        self.graph_control.clear()

        for i in range(len(test_matrix)):
            angle = 2 * math.pi * i / len(test_matrix)
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            new_id = self.graph_control.add_node()
            new_N = Node(new_id, x, y)
            # self.list_node.append(new_N)
            self.visual_nodes[new_id] = new_N
            self.scene.addItem(new_N)

        for i in range(len(test_matrix)):
            for j in range(len(test_matrix)):
                if (test_matrix[i][j]) > 0:
                    source = i + 1
                    dst = j + 1
                    self.graph_control.add_edge(source, dst)
                    # new_Edge = Edge(self.list_node[i], self.list_node[j], test_matrix[i][j])
                    if f'{dst}-{source}' not in self.list_edge:
                        # new_Edge = Edge(self.visual_nodes[source], self.visual_nodes[dst], test_matrix[i][j])
                        # self.scene.addItem(new_Edge)
                        # self.list_edge[f'{source}-{dst}'] = new_Edge
                        #
                        # self.list_node[i].add_edge(new_Edge)
                        # self.list_node[j].add_edge(new_Edge)

                        # 1. Берем объекты Node из словаря visual_nodes по их ID
                        node_source = self.visual_nodes[source]
                        node_dst = self.visual_nodes[dst]

                        # 2. Создаем графическое ребро
                        new_Edge = Edge(node_source, node_dst, test_matrix[i][j])
                        self.scene.addItem(new_Edge)

                        # 3. Сохраняем ребро в словарь ОБЕИМИ сторонами (ключевой момент для аниматора!)
                        self.list_edge[f'{source}-{dst}'] = new_Edge
                        self.list_edge[f'{dst}-{source}'] = new_Edge

                        # 4. Регистрируем ребро в самих узлах (чтобы линии тянулись при перетаскивании)
                        node_source.add_edge(new_Edge)
                        node_dst.add_edge(new_Edge)


    def generate_matrix(self, size):
        return [[1 if random.random() > 0.8 else 0 for _ in range(size)] for _ in range(size)]

class isAddButton(QPushButton):
    def __init__(self):
        super().__init__()
        self.setIcon(QIcon("add_circle_24dp_FFFFFF_FILL0_wght400_GRAD0_opsz24 (1).svg"))
        self.setIconSize(QSize(24, 24))
        self.setStyleSheet("""
                            QPushButton {
                                background-color: #3498db;
                                color: white;
                                border-radius: 10px;
                                padding: 10px;
                            }
                            QPushButton:pressed {
                                background-color: #2980b9;
                                padding-left: 15px; /* эффект смещения */
                                padding-top: 12px;
                            }
                        """)
        self.menu_add = QMenu(self)

        self.menu_add.setStyleSheet("""
                    QMenu {
                        background-color: #2c3e50;
                        color: white;
                        border: 1px solid #34495e;
                    }
                    QMenu::item:selected {
                        background-color: #3498db;
                    }
                """)

        add_list = QAction("Добавить списком смежности", self)
        add_matrix = QAction("Добавить матрицей", self)

        self.menu_add.addAction(add_list)
        self.menu_add.addAction(add_matrix)

        self.clicked.connect(self.show_sidebar_menu)
        # self.setMenu(self.menu_add)

    def show_sidebar_menu(self):
        button_rect = self.rect()
        point = button_rect.topRight()
        point.setX(point.x() + 10)
        global_point = self.mapToGlobal(point)
        self.menu_add.exec(global_point)

class isClickButton(QPushButton):
    def __init__(self):
        super().__init__()
        self.setIcon(QIcon("add_click_icon.svg"))
        self.setIconSize(QSize(24, 24))
        self.setStyleSheet("""
                    QPushButton {
                        background-color: #3498db;
                        color: white;
                        border-radius: 10px;
                        padding: 10px;
                    }
                    QPushButton:pressed {
                        background-color: #2980b9;
                        padding-left: 15px; /* эффект смещения */
                        padding-top: 12px;
                    }
                """)
    def enable(self):
        #походу пока не надо
        pass

class MyScene(QGraphicsScene):
    def __init__(self):
        super().__init__()
        self.cntNode = 2
        #self.setSceneRect(-500, -500, 1000, 1000)
        self.setSceneRect(-5000, -5000, 10000, 10000)


class MyView(QGraphicsView):
    def __init__(self, scene, graph_control:GraphControl, main_window):
        super().__init__(scene)
        self.my_scene = scene
        self.window = main_window
        self.setBackgroundBrush(QBrush(Qt.GlobalColor.white))
        self.graph_control = graph_control
        self.click = False
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)


    def mousePressEvent(self, event):
        pos = event.pos()
        item = self.itemAt(pos)
        if item and not isinstance(item, Node):
            parent = item.parentItem()
            if isinstance(parent, Node):
                item = parent #ии
        if self.click:
            if not item:
                self.setDragMode(QGraphicsView.DragMode.NoDrag)
                pos = self.mapToScene(pos) #перевод в координаты сцены, т.к. я сделал цену отсчета от нуля
                new_id = self.graph_control.add_node()
                n_add = Node(new_id, pos.x(), pos.y())
                self.my_scene.addItem(n_add)
                self.window.visual_nodes[new_id] = n_add

        else:
            if isinstance(item, Node):
                node_id = int(item.text_item.toPlainText())
                self.window.update_ui_node(node_id)
            self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)


        super().mousePressEvent(event)

    def enable_click_btn(self):
        self.click = not self.click

    #зум
    def wheelEvent(self, event):
        factor = 1.1 if event.angleDelta().y() > 0 else 0.9
        self.scale(factor, factor)





if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Window()
    # apply_stylesheet(app, theme='dark_teal.xml')
    window.show()

    sys.exit(app.exec())